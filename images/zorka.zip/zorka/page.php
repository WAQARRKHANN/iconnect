<?php get_header(); ?>
<?php get_template_part('content','top'); ?>
<?php  get_template_part('templates/page');?>
<?php get_footer(); ?>