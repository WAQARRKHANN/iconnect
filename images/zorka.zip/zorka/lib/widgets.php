<?php
require_once(locate_template('lib/widgets/g5plus-widget.php'));
require_once(locate_template('lib/widgets/footer-logo-widget.php'));
require_once(locate_template('lib/widgets/product-category-widget.php'));
require_once(locate_template('lib/widgets/product-featured-widget.php'));