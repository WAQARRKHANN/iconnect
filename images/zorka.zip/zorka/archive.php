<?php get_header(); ?>
<?php get_template_part( 'templates/archive'); ?>
<?php get_footer(); ?>