<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 6/23/2015
 * Time: 2:21 PM
 */
?>
<a class="product-link" href="<?php the_permalink(); ?>"></a>