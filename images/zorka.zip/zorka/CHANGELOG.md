# BONES CHANGE LOG & HISTORY

This theme is meant to make development easier & take
advantage of modern web development & design techniques.
For more information, please visit:

http://g5plus.net/

Author: G5Plus

*******************************************************************

/* 1.00 */
- create themes