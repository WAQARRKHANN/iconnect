# [G5Plus Theme Default](http://g5plus.net/)

## Features

* [Bootstrap](http://getbootstrap.com/)
* Organized file and template structure
* Cleaner HTML output of navigation menus

### Additional features

* Root relative URLs
* Nice search (`/search/query/`)
* Cleaner output of `wp_head` and enqueued assets markup

## Documentation

## Support

* Forums(http://forum.g5plus.net/) to ask questions and get support.