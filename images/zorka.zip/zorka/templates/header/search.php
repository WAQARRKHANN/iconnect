<div id="zorka-modal-search" tabindex="-1" role="dialog" aria-hidden="false" class="modal fade">
	<div class="modal-backdrop fade in"></div>
	<div class="zorka-modal-dialog zorka-modal-search fade in">
		<div data-dismiss="modal" class="zorka-dismiss-modal"><span class="pe-7s-close"></span></div>
		<div class="zorka-search-wrapper">
			<input id="search-ajax" type="search" placeholder="Search...">
			<button><i class="ajax-search-icon icon-search"></i></button>
		</div>
		<div class="ajax-search-result"></div>
	</div>
</div>